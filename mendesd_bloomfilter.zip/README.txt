Dev: Daniel Mendes
Date: 4/26/22
Assignment: Bloom Filter (1)

This program works as outlined in the requirements.
Since this program is a python script, simply type this command line:
	python3 ./bloomfilter.py -d dictionary.txt -i input.txt -o3 output3.txt -o5 output5.txt
Where any of the text files can be specified by the user
	If the output files are not present, they will be created
	If no relative/absolute path is specified, then files should be present in the current directory
